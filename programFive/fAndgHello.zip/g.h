#ifndef G_H
#define G_H

#include <iostream>

class g {
    public:
        static void hello();
};

#endif