
#ifndef F_H
#define F_H

#include <iostream>

class f {
    public:
        static void hello();
};


#endif