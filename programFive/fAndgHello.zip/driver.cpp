#pragma warning(disable: 4996)
#include<string>
#include<stdlib.h>
#include<time.h>
#include "f.h"
#include "g.h"

int main() {

    f::hello();
    g::hello();

    system("pause");
    return 0;
}