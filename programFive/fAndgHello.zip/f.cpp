#include <iostream>
#include "f.h"

void f::hello() {
    std::cout << "Hello from F" << std::endl;
}