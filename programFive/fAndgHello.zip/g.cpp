#include <iostream>
#include "g.h"

void g::hello() { 
    std::cout << "Hello from G" << std::endl;
}